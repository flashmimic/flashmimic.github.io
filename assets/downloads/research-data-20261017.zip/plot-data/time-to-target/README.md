# Time-to-target figure data (v9, 180-min budget)

Data behind the main results figure (paper Fig. 3): three-motion equal-weight
means over dance / walk tracking / box carrying with ±1 sample SD bands,
truncated at the first interpolated target crossing (RMSE ≤ 30 mm,
MPJPE ≤ 25 mm, PCK@50 mm ≥ 90%) or at 180 min.

- plotted_mean_sd_curves.csv: plotted mean/SD curves (per repository, metric).
- threshold_endpoints.csv: first-crossing or 180-min endpoints.
- motion_coverage.csv: measured vs used time coverage per motion.
- protocol.md: full reporting protocol (targets, interpolation, continuations).

Last-value continuations to 180 min apply to all Holosoma motions and to
BeyondMimic walk / box carrying; they add no training or evaluation samples.
Holosoma time is source-logged; training GPU unverified.
