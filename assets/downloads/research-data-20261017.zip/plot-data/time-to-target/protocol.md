# 三动作训练效率图：v9 论文统一口径

对应 [v9 三联图](three_actions_clean_overview.png)。图中比较 dance、walk tracking、box carrying 三个动作；四条曲线分别为 FlashMimic（FlashSAC）、Holosoma（FastSAC）、BeyondMimic（PPO）和 MJLab（PPO）。核心比较量是达到指定平均跟踪精度所需的训练 walltime，统一比较预算为 **180 minutes**。

本版 v9 的关键更新是：Holosoma walk 使用本地 3 小时训练 run 的 137 个真实评测 checkpoint（1.2752–179.0945 min），并仅在最后实测点之后按最后值延伸至 180 min。v8 保持不变。

## 1. 纵轴指标、定义和阈值

指标来自统一的 MuJoCo 完整动作评测。对每个 checkpoint 的 T 帧，先将参考身体按仿真 torso 平移和相对 torso yaw 对齐，再在 13 个非 torso 机器人 body-link 原点上计算三维欧氏距离。点集合为 pelvis，以及左右 hip-roll、knee、ankle-roll、shoulder-roll、elbow 和 wrist-yaw 对应的 link 原点。记第 t 帧第 b 个点的对齐误差为 `d[t,b]`（单位 m）：

```text
d[t,b]      = ||p_sim[t,b] - p_ref_aligned[t,b]||_2

RMSE_mm     = 1000 * sqrt( sum_t sum_b d[t,b]^2 / (13*T) )
MPJPE_mm    = 1000 *       sum_t sum_b d[t,b]   / (13*T)
PCK50_pct   = 100   *       sum_t sum_b I(d[t,b] <= 0.05) / (13*T)
```

| 面板 | 纵轴指标 | 趋势 | 平均曲线目标 |
|---|---|---|---:|
| (a) | Body position RMSE (mm) | 越小越好 | ≤ 30 mm |
| (b) | Body-point MPJPE (mm) | 越小越好 | ≤ 25 mm |
| (c) | PCK@50mm (%) | 越大越好 | ≥ 90% |

RMSE 先对位置距离平方求平均再开方，对较大误差更敏感；MPJPE 直接平均欧氏距离。PCK 对所有“帧–body-link”配对逐项判断，再求比例；PCK≥90%不要求一帧内 13 个点全部通过，也不表示连续 90% 的时间都保持正确。三项均表示 torso 平移和相对 yaw 对齐后的身体位置精度，不是全局轨迹位置误差，也不是各仓库原生 reward 的重命名。

本实验将 RMSE≤30 mm、MPJPE≤25 mm、PCK@50mm≥90% 作为仿真 eval 中高质量、无诊断失败表现对应的经验精度目标。阈值是本实验的统一比较口径，不声称是所有机器人任务的通用标准。

## 2. 均值曲线和阴影如何计算

先对每个仓库、每个动作的每个 checkpoint 计算三项物理指标，再使用该动作的累计训练 walltime。对相邻 checkpoint 的指标做分段线性插值，在同一 walltime `w` 得到 dance、walk、box 三个值后等权平均：

```text
mean(w) = [y_dance(w) + y_walk(w) + y_box(w)] / 3
SD(w)   = sqrt( sum_i [y_i(w) - mean(w)]^2 / (3 - 1) )
```

实线是三个动作的均值，半透明带是动作间 `±1` 个样本标准差（n=3，ddof=1）。它反映动作差异，不是多随机种子置信区间，也不是逐帧误差的标准差。各动作先独立计算 RMSE 后再平均，不把三个动作的帧拼接后重新开方；三个动作始终等权，dance 的帧数不会使其权重大于 box。

图中不使用 reward 反推、纵轴归一化或额外平滑。横轴是每个动作独立训练的 walltime，不是串行训练三个动作的总耗时，也不含离线 MuJoCo 推理耗时。

## 3. 180 分钟预算、截取和延伸规则

三个指标分别寻找对应平均曲线首次达到阈值的时间。若相邻点跨越阈值 `q`，交点按下式线性插值：

```text
τ = w_i + (q - mean_i) / (mean_(i+1) - mean_i)
        * (w_(i+1) - w_i)
```

- 在 180 min 内首次达标：曲线在 `τ` 停止，标出实际时间。
- 在 180 min 仍未达标：曲线在 `180.0 min` 停止，并标记为未达标；180 min 不是达标时间。
- 最后一个真实 checkpoint 早于 180 min：仅按已确认的规则用最后实测值恒定延伸到 180 min，并在输入 CSV 中以 `user_*_constant_extension` 标记。恒定延伸不是新增 checkpoint，也不伪造 TensorBoard 时间戳。

v9 的延伸段如下：

| 仓库 / 动作 | 实测末点 (min) | 延伸至 (min) | 规则 |
|---|---:|---:|---|
| Holosoma / dance | 178.566 | 180 | 最后实测值恒定延伸 |
| Holosoma / walk | 179.094 | 180 | 3 小时实测 run 的最后值恒定延伸 |
| Holosoma / box | 178.328 | 180 | 最后实测值恒定延伸 |
| BeyondMimic / walk | 147.076 | 180 | 作者确认的最后值恒定延伸 |
| BeyondMimic / box | 177.585 | 180 | 用户指定的最后值恒定延伸 |

FlashMimic 和 MJLab 的三动作共同覆盖范围均超过各自曲线的达标截取点；它们不需要延伸。首次达标只衡量 time to target，不等同于之后始终稳定满足阈值。

## 4. v9 当前端点结果

以下时间和末值直接取自 [`threshold_endpoints.csv`](threshold_endpoints.csv)。三个指标独立判断，因此同一仓库的三个达标时间不一定对应同一个 checkpoint；均值达标也不表示三个动作在该时刻都分别达标。

| 仓库（算法） | RMSE≤30 mm | MPJPE≤25 mm | PCK≥90% |
|---|---:|---:|---:|
| FlashMimic（FlashSAC） | 22.05 min，达标 | 11.00 min，达标 | 20.31 min，达标 |
| Holosoma（FastSAC） | 180.00 min，41.46 mm，未达标 | 180.00 min，33.05 mm，未达标 | 180.00 min，80.88%，未达标 |
| BeyondMimic（PPO） | 180.00 min，31.98 mm，未达标 | 176.64 min，达标 | 180.00 min，88.21%，未达标 |
| MJLab（PPO） | 84.93 min，达标 | 55.24 min，达标 | 88.60 min，达标 |

因此，FlashMimic 和 MJLab 在三个平均指标上均达到目标；BeyondMimic 仅 MPJPE 达标；Holosoma 在完整 180 min 预算内三个平均指标均未达标。这里的“未达标”是当前统一评测曲线在 180 min 的结果，不等价于继续训练必然无法达到目标。

## 5. 训练数据、评测来源和覆盖范围

本图的直接输入副本位于 [`source_csv/`](source_csv/)。所有指标由完整 MuJoCo rollout 导出，不通过 reward 公式反推。

| 仓库 | 当前 v9 数据来源 | walltime 字段 |
|---|---|---|
| FlashMimic | `flashmimic/plots/flashmimic_extended_serial_20261014/{dance,walk,box}/results.csv` | `walltime_4090_min` |
| BeyondMimic | `flashmimic/plots/beyondmimic_{dance,walk,box}_mujoco_4090/results.csv` | `walltime_4090_min` |
| Holosoma | `/home/user/下载/holosoma_v2_9_plots/results.csv` 的 Dance、Walk、Largebox 子集；完整来源副本见 `source_evaluation/holosoma_v2_9_plots/` | `training_walltime_min` |
| MJLab | `mjlab_six_motions_18figures_native/six_motions_native_13body_v1/{dance,walk,largebox}/results.csv` | `walltime_4090_min` |

Holosoma v2.9 共 398 个实测 checkpoint：dance 136、walk 137、box 125。walk 的 137 个 checkpoint 是 v9 的真实训练曲线主体，末点为 179.0945 min；仅最后 0.9055 min 使用恒定延伸。Holosoma 压缩包名称包含 4090，但训练 GPU 尚未独立核实，因此文中保留原始 TensorBoard walltime，不声称已完成独立同卡核验；MuJoCo 推理在 CPU 完成。

| 仓库 | dance：记录数 / 实测末点 min | walk：记录数 / 实测末点 min | box：记录数 / 实测末点 min | 三动作共同使用末端 |
|---|---:|---:|---:|---:|
| FlashMimic | 65 / 84.381 | 28 / 43.673 | 32 / 39.903 | 39.903 min |
| Holosoma | 136 / 178.566 | 137 / 179.094 | 125 / 178.328 | 180.000 min（含延伸） |
| BeyondMimic | 26 / 201.248 | 20 / 147.076 | 21 / 177.585 | 180.000 min（含延伸） |
| MJLab | 61 / 327.350 | 61 / 277.221 | 61 / 306.643 | 277.221 min |

共有 **773 条实测 checkpoint–动作评测记录**；其中训练 walltime不超过180 min的实测记录为698条。延伸行单独保存，不计入实测 checkpoint 数，也不代表新的模型评测。

## 6. “100% 成功”阈值的可复核表述

对 `source_csv/` 中 walltime≤180 min 的实测 checkpoint–动作记录回查：分别满足 RMSE、MPJPE、PCK 门槛的记录数为 141、176、152；同时满足三个门槛的记录数为141。它们的 `failure_status` 均为 `none` 或 `completed_no_diagnostic_failure`，即源评测导出器均未报告诊断失败；对应观测比例均为100%。这些集合相互重叠，不是独立训练试验。

论文中建议写成：

> 我们将 RMSE≤30 mm、MPJPE≤25 mm 和 PCK@50mm≥90% 作为与高质量仿真跟踪相对应的经验精度目标。在训练 walltime 不超过180分钟的现有 checkpoint–动作评测记录中，分别满足三个门槛的141、176和152条记录，以及同时满足三个门槛的141条记录，均未被源评测器标记为诊断失败，观测到的无诊断失败比例为100%。该统计针对有限的完整动作评测记录，不等价于随机种子成功率、真实机器人成功率或三动作均值过线时每个动作必然成功。

## 7. 论文可用的结果分析

### 7.1 达到同一平均精度的时间优势

FlashMimic 三项指标的首次达标时间分别为 22.05、11.00、20.31 min；MJLab 分别为84.93、55.24、88.60 min。MJLab 相对 FlashMimic 的 time-to-target 比例分别为 **3.85×、5.02×、4.36×**，对应 FlashMimic 训练时间减少 **74.04%、80.09%、77.08%**。这支持“在当前动作集合和记录配置下，FlashMimic 更快达到指定平均身体位置精度”的结论；不能将这些比例直接称为通用仿真吞吐率或单独某个优化器的加速比。

在相同 20 min walltime 插值点，四仓库三指标均值为：

| 仓库 | RMSE (mm) | MPJPE (mm) | PCK (%) |
|---|---:|---:|---:|
| FlashMimic | 31.29 | 23.82 | 89.91 |
| Holosoma | 48.76 | 39.09 | 73.87 |
| BeyondMimic | 53.33 | 39.27 | 75.52 |
| MJLab | 40.53 | 30.54 | 82.01 |

这些数值用于补充说明相同时间预算下的精度差异；主图仍以首次达到目标的时间为主要比较量。

### 7.2 未达标曲线的解释

Holosoma 的三项均值在 180 min 仍为 41.46 mm、33.05 mm 和80.88%，因此应写成“在统一180分钟预算内未达到目标”。walk 的主体数据是真实 3 小时 run，最后不足1分钟才做恒定延伸；不能把该延伸误写成额外训练或新的 checkpoint。

BeyondMimic 在180 min 的 RMSE和PCK分别为31.98 mm和88.21%，略未达到阈值；MPJPE在176.64 min首次达到25 mm。它是“部分指标达标”，不能概括为三项全部达标。均值未达标也不表示所有动作都未达标，动作间难度差异应结合 `full_mean_sd_curves.csv` 和逐动作输入表解释。

阴影是三个动作之间的 ±1 SD，表示动作异质性，不是重复实验的置信区间。首次交点不等价于持续收敛；若论文需要“稳定达到”，必须另行预先定义持续时间窗口并重新统计。

## 8. 论文正文和图注模板

### 中文正文

> 我们在 dance、walk tracking 和 box carrying 三个动作上比较 FlashMimic（FlashSAC）、Holosoma（FastSAC）、BeyondMimic（PPO）和 MJLab（PPO）的训练效率。各方法的中间 checkpoint 在 MuJoCo 中完成完整动作评测。参考身体经 torso 平移和相对 yaw 对齐后，在13个预定义机器人 body-link 原点上计算 Body Position RMSE、body-point MPJPE 和 PCK@50mm。各动作先独立计算指标，再按训练 walltime 线性插值并等权求三动作均值；阴影表示动作间 ±1 个样本标准差。我们以平均 RMSE≤30 mm、MPJPE≤25 mm 和 PCK≥90% 作为统一精度目标。FlashMimic 首次达到三个目标分别需要22.05、11.00和20.31分钟，而 MJLab分别需要84.93、55.24和88.60分钟。Holosoma 使用真实的3小时 walk 训练曲线并在最后实测点后延伸至180分钟，但在统一180分钟预算内三个目标均未达到；BeyondMimic仅在MPJPE上达到目标。结果表明，在当前评测配置和动作集合下，FlashMimic 更快达到指定的平均身体位置精度。

### English results paragraph

> We compare the training efficiency of FlashMimic (FlashSAC), Holosoma (FastSAC), BeyondMimic (PPO), and MJLab (PPO) on dance, walk tracking, and box carrying. Intermediate checkpoints are evaluated on complete motions in MuJoCo. After torso-translation and relative-yaw alignment, we compute body-position RMSE, body-point MPJPE, and PCK@50 mm over 13 predefined robot body-link origins. Metrics are first computed per motion and then linearly interpolated in training walltime and averaged equally across the three motions; shading denotes ±1 sample standard deviation across motions. FlashMimic first reaches the mean RMSE, MPJPE, and PCK targets in 22.05, 11.00, and 20.31 minutes, compared with 84.93, 55.24, and 88.60 minutes for MJLab. Holosoma uses the measured three-hour walk run followed by a last-value continuation to 180 minutes, but does not reach any target within the 180-minute budget; BeyondMimic reaches only the MPJPE target. These results support faster attainment of the specified mean tracking accuracy under the evaluated configurations.

### English figure caption

> Training walltime versus tracking accuracy on dance, walk tracking, and box carrying. Curves show equal-motion means of torso-aligned body-position RMSE, body-point MPJPE, and PCK@50 mm computed from complete MuJoCo evaluations; shaded regions denote ±1 sample standard deviation across motions (n=3). Dashed lines indicate the targets RMSE≤30 mm, MPJPE≤25 mm, and PCK≥90%. Each curve ends at its first interpolated target crossing or at 180 min when the target is not reached; labels report the endpoint time. Holosoma walk uses 137 measured checkpoints through 179.09 min and a last-value continuation to 180 min; the continuation is not a new checkpoint. The time axis is linear to 60 min and compressed threefold thereafter without omitting an interval. No reward inversion, smoothing, or endpoint normalization is used.

## 9. 文件和复核入口

- [主图](three_actions_clean_overview.png)、[PDF](three_actions_clean_overview.pdf)、[SVG](three_actions_clean_overview.svg)
- [`source_csv/`](source_csv/)：逐仓库、逐动作实测结果及带标记的恒定延伸文件
- [`full_mean_sd_curves.csv`](full_mean_sd_curves.csv)：截取前的三动作值、均值与 SD
- [`plotted_mean_sd_curves.csv`](plotted_mean_sd_curves.csv)：最终绘图曲线数据
- [`threshold_endpoints.csv`](threshold_endpoints.csv)：端点、阈值状态和共同覆盖范围
- [`motion_coverage.csv`](motion_coverage.csv)：每个动作的实测末点和实际使用末点
- [`source_evaluation/holosoma_v2_9_plots/`](source_evaluation/holosoma_v2_9_plots/)：Holosoma 398 个 checkpoint 的原始评测结果、清单与验证文件
- [`plot_three_actions_clean_v9.py`](plot_three_actions_clean_v9.py)：v9 重建脚本
- [`validation.json`](validation.json)：图形和数据自动检查；当前 `all_figures_passed=true`

若今后补充新的实测 checkpoint、统一核验 Holosoma 训练 GPU，或把首次达标改成持续达标窗口，应同步更新本文件、端点 CSV、图注和正文，不应继续沿用当前 v9 的端点结论。

## 10. 增量补充：逐动作末端、数据证据和图形核验

### 10.1 各动作最后实测 checkpoint

下表用于解释三动作均值在 180 min 的组成。数值是每个动作最后一个**真实 MuJoCo checkpoint**的指标，不是把均值曲线反推回单个动作；Holosoma 与 BeyondMimic 的恒定延伸段沿用对应实测末值。

| 仓库 | 动作 | 实测 checkpoint 数 | 实测末点 (min) | RMSE (mm) | MPJPE (mm) | PCK (%) | 源状态 |
|---|---|---:|---:|---:|---:|---:|---|
| FlashMimic | dance | 65 | 84.381 | 31.02 | 21.56 | 89.93 | completed_no_diagnostic_failure |
| FlashMimic | walk | 28 | 43.673 | 32.84 | 24.95 | 86.96 | completed_no_diagnostic_failure |
| FlashMimic | box | 32 | 39.903 | 31.94 | 26.06 | 88.45 | completed_no_diagnostic_failure |
| Holosoma | dance | 136 | 178.566 | 39.89 | 31.96 | 81.98 | none |
| Holosoma | walk | 137 | 179.094 | 33.39 | 27.57 | 88.21 | none |
| Holosoma | box | 125 | 178.328 | 51.12 | 39.60 | 72.45 | none |
| BeyondMimic | dance | 26 | 201.248 | 24.38 | 18.30 | 94.07 | completed_no_diagnostic_failure |
| BeyondMimic | walk | 20 | 147.076 | 29.13 | 22.68 | 90.90 | completed_no_diagnostic_failure |
| BeyondMimic | box | 21 | 177.585 | 40.97 | 32.37 | 80.71 | completed_no_diagnostic_failure |
| MJLab | dance | 61 | 327.350 | 23.45 | 17.14 | 95.42 | none |
| MJLab | walk | 61 | 277.221 | 23.74 | 17.75 | 95.60 | none |
| MJLab | box | 61 | 306.643 | 30.67 | 23.81 | 89.11 | none |

`none` 表示该来源结果没有附加诊断失败文本；`completed_no_diagnostic_failure` 是另一导出器对相同含义的显式标记。两者在本报告中都表示“源评测器未报告诊断失败”，不把它们解释成真实机器人成功率。

Holosoma walk 的 179.094–180 min 只复制最后实测值：RMSE 33.3866 mm、MPJPE 27.5741 mm、PCK 88.2051%。因此，Holosoma 在 180 min 的三动作均值分别为 41.4632 mm、33.0451 mm 和 80.8785%；均值没有因延伸而改善。

### 10.2 真实点、延伸点和绘图点的数量

`all_motion_input_points.csv` 以长表形式保存 2,334 个“仓库–动作–指标–时间”行，其中 2,319 行来自真实 MuJoCo checkpoint，15 行来自五个动作延伸点（每个延伸点包含三个指标）。延伸点的 `point_kind` 明确记录为：

- `user_validated_constant_extension`：BeyondMimic walk，3 个指标；
- `user_requested_constant_extension`：BeyondMimic box、Holosoma dance/walk/box，共12个指标。

这15行只用于把曲线显示到统一的180 min边界，并参与边界处的三动作均值；它们不增加实测 checkpoint 数量、不增加新的模型样本，也不改变 `source_csv/*_results.csv` 中的原始实测记录。需要只分析真实评测时，应过滤 `point_kind == measured_mujoco_checkpoint`。

### 10.3 时间字段、设备和可比性

v9 不执行 5090→4090 倍率换算。FlashMimic、BeyondMimic 和 MJLab 使用其评测 CSV 中的 `walltime_4090_min`；Holosoma 使用 TensorBoard 对应 iteration 的 `training_walltime_min`，并以第一次记录的第100轮为零点。Holosoma 数据包名称包含“4090”，但训练 GPU 没有在本地独立核实，因此论文中应写“reported walltime; training GPU unverified”，不能写成已完成四仓库同卡复验。

评测阶段使用 MuJoCo CPU rollout；训练设备和评测设备不是同一个概念。walltime 只计训练过程，不计模型导出、文件传输和离线 MuJoCo 评测时间。四个仓库的原生策略、控制频率和场景实现仍可能存在系统差异，所以图支持的是“在记录配置下达到统一物理指标所需的 walltime”比较，不是对所有硬件或所有实现的绝对吞吐率结论。

### 10.4 图的时间坐标和输出规范

横轴的真实时间映射为：

```text
u(t) = t                         (t <= 60 min)
u(t) = 60 + (t - 60) / 3         (t > 60 min)
```

因此 0、20、40、60 min 在线性段等距；60 min 后仍保留所有时间，只将纸面宽度压缩为原来的三分之一，并以20 min次刻度辅助读数。曲线数据本身仍使用真实分钟，不能用图上的纸面距离直接代替 walltime。

v9 输出为三联总图和三个单指标图，每个图均提供 PNG、PDF 和 SVG。PNG 为600 dpi，字体为嵌入/可复现的 Liberation Sans；均值线宽约1.3 pt，阴影透明度约14%，端点用实心仓库标记和同色时间标签表示。没有星号、dagger 或未披露的状态符号。图形自动检查结果为：四个图均 `passed=true`，无裁切文字、无重叠文字、无标签穿越曲线；总图尺寸180 × 52.8 mm，单指标图尺寸88 × 66.71 mm。

### 10.5 审稿人应如何解读“达标”和“收敛”

1. **达标是均值线的首次交点。**例如 FlashMimic 的 RMSE 端点22.05 min表示三动作均值首次达到30 mm，不保证 walk 或 box 在同一时刻都低于30 mm。
2. **三个指标分别截取。**MPJPE 的端点11.00 min和PCK的端点20.31 min不是同一个模型快照的联合结论；若需要联合达标，应单独寻找同一 checkpoint 同时满足三项的时刻。
3. **未达标曲线延伸到180 min不等于新增证据。**Holosoma walk 的最后0.9055 min、dance和box的末段、BeyondMimic walk和box的末段均为常值显示延伸；读者应在数据表和图注中看到这一披露。
4. **首次达标不等于稳定收敛。**训练指标可能在阈值两侧波动。当前图没有平滑、单调化或持续窗口判据，因此结论应写“first reaches”或“首次达到”，不应写“从该时间起始终稳定”。
5. **均值不等于最终精度排名。**FlashMimic、BeyondMimic 和 MJLab 有些原始记录超过180 min，但主图按目标首次交点截断；曲线末端的相同高度主要用于读出 time to target，不用于比较无限训练后的最优精度。

### 10.6 可直接放入论文的补充结果段落

**中文：**

> 在统一180 min预算下，FlashMimic 的三项平均精度均达到目标，首次达到 RMSE≤30 mm、MPJPE≤25 mm 和 PCK@50mm≥90% 分别需要22.05、11.00和20.31 min。MJLab对应时间为84.93、55.24和88.60 min；相对于 FlashMimic，其 time-to-target 分别为3.85×、5.02×和4.36×。BeyondMimic仅在MPJPE上于176.64 min达到目标，RMSE和PCK在180 min仍分别为31.98 mm和88.21%。Holosoma的walk曲线来自137个真实checkpoint，覆盖至179.09 min，并以最后实测值延伸至180 min；其三项平均指标在180 min分别为41.46 mm、33.05 mm和80.88%，均未达到目标。上述延伸不代表额外训练或新的评测样本。

**English:**

> Under a common 180-min budget, FlashMimic reaches the three mean accuracy targets at 22.05, 11.00, and 20.31 min for RMSE, MPJPE, and PCK@50 mm, respectively. The corresponding MJLab times are 84.93, 55.24, and 88.60 min, giving MJLab-to-FlashMimic time-to-target ratios of 3.85×, 5.02×, and 4.36×. BeyondMimic reaches only the MPJPE target at 176.64 min; its RMSE and PCK remain at 31.98 mm and 88.21% at 180 min. Holosoma uses 137 measured walk checkpoints through 179.09 min followed by an explicitly disclosed last-value continuation to 180 min. Its 180-min mean values are 41.46 mm, 33.05 mm, and 80.88% for RMSE, MPJPE, and PCK, respectively, and none reaches the target. The continuation adds no training checkpoint or new evaluation sample.

### 10.7 建议引用的文件关系

- 本文件 [`paper_reporting_protocol_180min.md`](paper_reporting_protocol_180min.md)：论文统一口径、方法、结果和限制。
- [`README.md`](README.md)：v9 交付目录的简要入口。
- [`paper_figure_quick_guide.md`](paper_figure_quick_guide.md)：图形尺寸、字体、颜色、时间轴和图注细节。
- [`holosoma_walk_3h_v9_update.md`](holosoma_walk_3h_v9_update.md)：Holosoma walk 3 小时 run 的来源及末段延伸。
- [`threshold_endpoints.csv`](threshold_endpoints.csv)：机器可读的阈值端点。
- [`motion_coverage.csv`](motion_coverage.csv)：动作级实测和实际使用覆盖范围。
- [`validation.json`](validation.json)：自动版式与延伸规则检查。

后续若改用新的 walk 权重、增加真实 checkpoint、统一训练 GPU，或把首次交点改为持续达标窗口，应在本文件中同步更新数值、来源和论文措辞；不要只替换图片而保留旧的端点表或文字结论。


### 10.8 附录：单动作首次达标时间（不替代主图端点）

为了区分“平均曲线达标”和“单个动作达标”，下面给出按同一阈值、同一线性插值规则计算的单动作首次交点。`—` 表示该动作在其可用的 180 min 数据范围内没有达到对应阈值。该表是诊断动作差异的辅助表，主图和论文主结论仍使用三动作等权均值的端点。

| 仓库 | 动作 | RMSE≤30 mm (min) | MPJPE≤25 mm (min) | PCK≥90% (min) |
|---|---|---:|---:|---:|
| FlashMimic | dance | 12.87 | 5.34 | 6.10 |
| FlashMimic | walk | — | 26.79 | 30.90 |
| FlashMimic | box | 10.71 | 10.45 | 10.56 |
| Holosoma | dance | — | — | — |
| Holosoma | walk | — | — | 177.76 |
| Holosoma | box | — | — | — |
| BeyondMimic | dance | 114.30 | 78.20 | 100.93 |
| BeyondMimic | walk | 87.20 | 48.73 | 80.41 |
| BeyondMimic | box | — | — | — |
| MJLab | dance | 73.85 | 54.51 | 62.72 |
| MJLab | walk | 27.60 | 17.26 | 26.79 |
| MJLab | box | — | 171.76 | — |

单动作表也显示了为什么均值曲线不应被解释成每个动作同时达标：例如 FlashMimic 的平均 RMSE 在22.05 min 达标，但 walk 单独没有在其观测范围内达到30 mm；Holosoma walk 的 PCK 曾在177.76 min短暂跨过90%，随后末点为88.21%，所以不能称为稳定达标。该表不改变三动作均值端点，也不把一次交点解释成持续收敛。
