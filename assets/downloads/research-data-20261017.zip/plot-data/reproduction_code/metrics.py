import numpy as np
TRACK=['pelvis','left_hip_roll_link','left_knee_link','left_ankle_roll_link','right_hip_roll_link','right_knee_link','right_ankle_roll_link','torso_link','left_shoulder_roll_link','left_elbow_link','left_wrist_yaw_link','right_shoulder_roll_link','right_elbow_link','right_wrist_yaw_link']
EE=[3,6,10,13]
def inv(q): return q*np.array([-1,-1,-1,1])
def mul(a,b):
 av,aw=a[...,:3],a[...,3:]; bv,bw=b[...,:3],b[...,3:]
 return np.concatenate([aw*bv+bw*av+np.cross(av,bv),aw*bw-np.sum(av*bv,axis=-1,keepdims=True)],-1)
def apply(q,v): return v+2*np.cross(q[...,:3],np.cross(q[...,:3],v)+q[...,3:]*v)
def angle(a,b):
 a=a/np.maximum(np.linalg.norm(a,axis=-1,keepdims=True),1e-12); b=b/np.maximum(np.linalg.norm(b,axis=-1,keepdims=True),1e-12)
 return 2*np.arccos(np.clip(np.abs(np.sum(a*b,axis=-1)),0,1))
def evaluate(rp,rq,ap,aq,names):
 ids=[list(names).index(x) for x in TRACK]; rp,rq,ap,aq=[x[:,ids] for x in (rp,rq,ap,aq)]
 dq=mul(aq[:,7],inv(rq[:,7])); x,y,z,w=np.moveaxis(dq,-1,0); yaw=np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))
 yq=np.stack([np.zeros_like(yaw),np.zeros_like(yaw),np.sin(yaw/2),np.cos(yaw/2)],-1)[:,None]
 aligned=ap[:,7,None]+apply(yq,rp-rp[:,7,None]); alignedq=mul(yq,rq)
 pos=np.linalg.norm(aligned-ap,axis=-1); ori=angle(alignedq,aq); root=np.linalg.norm(rp[:,7]-ap[:,7],axis=-1)
 fail=(pos.mean(-1)>.5)|(ori[:,7]>.8)
 vals={'succ_pct':float(100*(not fail.any())),'Root_Ref_global_anchor_pos_mm':float(root.mean()*1000),'Body_MPJPE_r_mm':float(pos.mean()*1000),'Body_Ori_r_rad':float(ori.mean()),'EE_Wrist_Pos_r_mm':float(pos[:,EE].mean()*1000),'EE_Wrist_Ori_r_rad':float(ori[:,EE].mean()),'frames':len(rp),'first_failure_frame':int(np.flatnonzero(fail)[0]) if fail.any() else None,'anchor':'torso_link','body_names':TRACK,'ee_names':[TRACK[i] for i in EE],'alignment':'full XYZ translation + torso relative-quaternion yaw; same-frame samples','success_definition':'single deterministic trial; any frame aligned mean 14 body position >0.5m or aligned torso quaternion angle >0.8rad fails'}
 return vals,dict(body_pos_error=pos,body_ori_error=ori,root_error=root,failure=fail)
