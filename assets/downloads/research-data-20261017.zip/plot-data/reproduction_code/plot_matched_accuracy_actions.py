"""Compare measured MuJoCo curves at each FlashMimic final-checkpoint target.

No extrapolation: distinguish interpolated crossings, initial checkpoints that
already meet a target, and targets never reached by available checkpoints.
"""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, ScalarFormatter
import numpy as np

BASE=Path('/home/user/flashmimic/plots')
METRIC_PATH=BASE/'dance_pck_4090_v1/scripts/metrics.py'
spec=importlib.util.spec_from_file_location('metrics',METRIC_PATH)
metric=importlib.util.module_from_spec(spec);spec.loader.exec_module(metric)
KEYS=['bodypos_rmse_mm','bodypos_mpjpe_mm','pck50_pct']
PANELS=[('bodypos_rmse_mm','Body position RMSE','Body position RMSE (mm; log scale)','mm'),
        ('bodypos_mpjpe_mm','Body point MPJPE','Body point MPJPE (mm; log scale)','mm'),
        ('pck50_pct','PCK@50 mm','PCK@50 mm (%)','%')]
NAMES={'walk':'Walk tracking','run':'Run','sprint':'Sprint','flip':'Flip','box':'Box carrying','crawl':'Crawl'}
RED='#d1495b';BLUE='#2878b5'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(action,repo):
    source=BASE/f'{repo}_{action}_mujoco_4090'/'results.csv'
    with source.open(newline='') as f:
        rows=sorted(csv.DictReader(f),key=lambda r:float(r['walltime_4090_min']))
    assert np.all(np.diff([float(r['walltime_4090_min']) for r in rows])>0)
    refs=None
    for row in rows:
        assert row['time_status']=='measured_4090' and '4090' in row['training_gpu']
        assert 'MuJoCo 3.11.0' in row['evaluation_simulator']
        assert sha(row['trajectory'])==row['trajectory_sha256']
        with np.load(row['trajectory']) as raw:
            arrays=[raw[k] for k in ['reference_pos_m','reference_quat_xyzw','actual_pos_m','actual_quat_xyzw']]
            assert len(arrays[0])==int(row['frames'])
            assert all(np.isfinite(a).all() for a in arrays)
            _,e=metric.evaluate(*arrays,raw['body_names'].tolist())
            current={k:raw[k].copy() for k in ['reference_pos_m','reference_quat_xyzw','body_names']}
        if refs is None:refs=current
        else:assert all(np.array_equal(refs[k],current[k]) for k in refs)
        d=e['body_pos_error'][:,[i for i,n in enumerate(metric.TRACK) if n!='torso_link']]
        values=[1000*np.sqrt(np.mean(d*d)),1000*np.mean(d),100*np.mean(d<=.05)]
        assert all(np.isclose(float(row[k]),v,rtol=1e-10,atol=1e-10) for k,v in zip(KEYS,values))
    return rows,refs,dict(repository=repo,path=str(source),sha256=sha(source),checkpoint_count=len(rows))


def crossing(rows,key,target):
    x=np.array([float(r['walltime_4090_min']) for r in rows])
    y=np.array([float(r[key]) for r in rows])
    ids=np.flatnonzero(y>=target if key=='pck50_pct' else y<=target)
    if not len(ids):
        return dict(status='not_reached_by_available_checkpoints',time_min=None,
                    last_observed_time_min=float(x[-1]),best_observed_value=float(y.max() if key=='pck50_pct' else y.min()))
    i=int(ids[0])
    if i==0:
        return dict(status='already_met_at_first_checkpoint',time_min=float(x[0]),iteration=int(rows[0]['iteration']),
                    first_observed_value=float(y[0]),exact_crossing_time_unknown=True)
    fraction=(target-y[i-1])/(y[i]-y[i-1])
    t=float(x[i-1]+fraction*(x[i]-x[i-1]))
    assert 0<=fraction<=1 and x[i-1]<=t<=x[i]
    return dict(status='interpolated_first_observed_crossing',time_min=t,hit_index=i,
                bracket_iterations=[int(rows[j]['iteration']) for j in [i-1,i]],
                bracket_walltime_min=[float(x[j]) for j in [i-1,i]],
                bracket_values=[float(y[j]) for j in [i-1,i]],
                interpolation='linear in untransformed metric values and walltime; not a new checkpoint')


def make(action):
    out=BASE/f'{action}_beyondmimic_flashmimic_mujoco_4090'/'matched_accuracy';out.mkdir(exist_ok=True,parents=True)
    flash,fr,fs=load(action,'flashmimic');beyond,br,bs=load(action,'beyondmimic')
    assert all(np.array_equal(fr[k],br[k]) for k in fr)
    assert int(flash[-1]['iteration'])==17500
    fx=np.array([float(r['walltime_4090_min']) for r in flash])
    bx=np.array([float(r['walltime_4090_min']) for r in beyond])
    records=[]
    for key,_,_,unit in PANELS:
        target=float(flash[-1][key]);c=crossing(beyond,key,target)
        records.append(dict(action=action,metric=key,target=target,unit=unit,
                            flashmimic_final_iteration=17500,flashmimic_final_walltime_min=float(fx[-1]),**c))
    max_time=max([float(fx[-1])]+[r['last_observed_time_min'] if r['time_min'] is None else r['time_min'] for r in records])
    step=2 if max_time<=10 else 5 if max_time<=25 else 10 if max_time<=60 else 20 if max_time<=170 else 30
    xmax=math.ceil(max_time/step)*step
    if xmax-max_time<step*.12:xmax+=step
    points=[]
    fig,axes=plt.subplots(1,3,figsize=(18,6),sharex=True)
    for ax,(key,title,label,unit),rec in zip(axes,PANELS,records):
        target=rec['target'];fy=np.array([float(r[key]) for r in flash]);by=np.array([float(r[key]) for r in beyond])
        ax.axhline(target,color='#89939f',lw=.9,ls=(0,(4,4)),zorder=1)
        status=rec['status']
        if status=='interpolated_first_observed_crossing':
            n=rec['hit_index'];t=rec['time_min']
            ax.plot(bx[:n],by[:n],color=BLUE,marker='s',ms=4.7,lw=2,mec='white',mew=.5,label='BeyondMimic')
            ax.plot([bx[n-1],t],[by[n-1],target],color=BLUE,lw=2,ls='--')
            ax.plot(t,target,marker='D',ms=6,mfc='white',mec=BLUE,mew=1.5,zorder=5)
            ax.annotate(f'{t:.2f} min*',(t,target),xytext=(0,-24),textcoords='offset points',ha='right',fontsize=10,color=BLUE)
            points.append(dict(repository='BeyondMimic',metric=key,walltime_4090_min=t,value=target,point_kind='linear_interpolation',iteration=''))
            subtitle=''
        elif status=='already_met_at_first_checkpoint':
            n=1
            ax.plot(bx[:n],by[:n],color=BLUE,marker='s',ms=6,ls='None',mec='white',mew=.5,label='BeyondMimic (first checkpoint)')
            ax.annotate(f'Already met\n{bx[0]:.2f} min',(bx[0],by[0]),xytext=(9,10),textcoords='offset points',ha='left',fontsize=9,color=BLUE)
            subtitle='BeyondMimic: already met at first checkpoint'
        else:
            n=len(beyond)
            ax.plot(bx,by,color=BLUE,marker='s',ms=4.7,lw=2,mec='white',mew=.5,label='BeyondMimic')
            ax.annotate(f'{bx[-1]:.2f} min\nnot reached',(bx[-1],by[-1]),xytext=(-5,14),textcoords='offset points',ha='right',fontsize=9,color=BLUE)
            subtitle='BeyondMimic: target not reached'
        ax.plot(fx,fy,color=RED,marker='o',ms=4.7,lw=2,mec='white',mew=.5,label='FlashMimic')
        near_left=fx[-1]/xmax<.12
        ax.annotate(f'{fx[-1]:.2f} min',(fx[-1],target),xytext=(7 if near_left else 0,15),textcoords='offset points',ha='left' if near_left else 'center',fontsize=10,color=RED)
        for repo,x,y,rows,count in [('FlashMimic',fx,fy,flash,len(flash)),('BeyondMimic',bx,by,beyond,n)]:
            for t,v,row in zip(x[:count],y[:count],rows[:count]):
                points.append(dict(repository=repo,metric=key,walltime_4090_min=float(t),value=float(v),point_kind='measured',iteration=row['iteration']))
        target_label=f'{target:.2f}%' if key=='pck50_pct' else f'{target:.2f} mm'
        ax.set_title(f'{title}\nMatched target: {target_label}'+(f'\n{subtitle}' if subtitle else ''),fontsize=11.5,pad=14)
        ax.set_xlabel('Training walltime on RTX 4090 (min)');ax.set_ylabel(label)
        ax.set_xlim(0,xmax);ax.xaxis.set_major_locator(MaxNLocator(nbins=6,steps=[1,2,2.5,5,10]))
        if key=='pck50_pct':
            ax.set_ylim(0,100);ax.legend(frameon=False,loc='upper right' if status=='already_met_at_first_checkpoint' else 'lower right',fontsize=9)
        else:
            ax.set_yscale('log');lo=min(target,fy.min(),by[:n].min())*.58;hi=max(target,fy.max(),by[:n].max())*1.25
            ax.set_ylim(lo,hi);ax.set_yticks([v for v in [10,20,30,40,60,100,200,400,600,1000,2000] if lo<=v<=hi])
            ax.yaxis.set_major_formatter(ScalarFormatter());ax.minorticks_off();ax.legend(frameon=False,loc='lower right' if status=='already_met_at_first_checkpoint' else 'upper right',fontsize=9)
        ax.grid(color='#e1e7ef',lw=.7);ax.set_axisbelow(True);ax.spines[['top','right']].set_visible(False)
    fig.suptitle(f'{NAMES[action]} | FlashMimic final-accuracy targets | MuJoCo evaluation',fontsize=16,y=.985)
    fig.text(.5,.099,f'MuJoCo 3.11.0 (CPU); identical {len(fr["reference_pos_m"])}-frame reference; 13 body links; torso XYZ + yaw alignment; RTX 4090 training.',ha='center',fontsize=9.5,color='#526079')
    fig.text(.5,.060,'* Hollow diamond / dashed final segment: interpolated crossing. Not reached: full available curve. Already met: first measured point only.',ha='center',fontsize=9,color='#526079')
    footer='Targets use FlashMimic model_17500; all 7 FlashMimic checkpoints retained, including reversals; no smoothing or extrapolation.'
    if action=='crawl':footer='Crawl: FlashMimic final accuracy regressed; BeyondMimic already meets all targets initially. This threshold comparison does not show a speed advantage.'
    if action=='flip':footer='Flip: BeyondMimic checkpoints end at iteration 1500; target not reached in available data. This is not proof of eventual non-convergence.'
    if action=='sprint':footer='Sprint: FlashMimic final accuracy remains low; matching this weak target does not establish high-accuracy convergence.'
    fig.text(.5,.024,footer,ha='center',fontsize=9,color='#526079')
    fig.tight_layout(rect=(0,.155,1,.94),w_pad=2)
    for ext in ['png','pdf','svg']:fig.savefig(out/f'{action}_three_metrics_matched_accuracy.{ext}',dpi=220)
    plt.close(fig)
    points.sort(key=lambda p:(p['metric'],p['repository'],p['walltime_4090_min']))
    with (out/'plotted_points.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(points[0]));w.writeheader();w.writerows(points)
    metadata=dict(action=action,sources=[fs,bs],targets=records,reference_arrays_identical=True,
                  source_trajectory_hashes_and_metrics_recomputed=True,metric_code=str(METRIC_PATH),
                  target_definition='FlashMimic model_17500 measured metric; all seven FlashMimic checkpoints retained, not necessarily first hitting time',
                  interpolation='linear in original metric units and walltime; estimated not measured',
                  x_axis=dict(scale='linear',unit='RTX4090 training walltime min',limits=[0,xmax],no_time_rescaling=True),
                  simulator='MuJoCo3.11 CPU',no_smoothing=True,no_extrapolation=True,
                  scene_scope='Each policy retains native model, controller and physics step; metric algorithm and reference arrays are shared.')
    (out/'thresholds.json').write_text(json.dumps(metadata,indent=2))
    lines=[f'# {NAMES[action]}：FlashMimic 与 BeyondMimic 同阈值截取','',
           f'主图：`{action}_three_metrics_matched_accuracy.png/pdf/svg`。以 FlashMimic 17500 轮指标为各子图阈值，保留其全部7个实测点。','',
           '| 指标 | 阈值 | FlashMimic末轮时间 | BeyondMimic状态与时间 |','|---|---:|---:|---|']
    for r in records:
        desc=(f"线性插值约 {r['time_min']:.2f} min" if r['status']=='interpolated_first_observed_crossing' else
              f"首个检查点已达标，{r['time_min']:.2f} min（实际首次达到时间未知）" if r['status']=='already_met_at_first_checkpoint' else
              f"现有检查点未达标；最后观测 {r['last_observed_time_min']:.2f} min")
        lines.append(f"| {r['metric']} | {r['target']:.6f} {r['unit']} | {r['flashmimic_final_walltime_min']:.6f} min | {desc} |")
    lines+=['','空心菱形和末段虚线为线性插值估计，不是新推理检查点；不外推未达阈值的时间。若第一个检查点已达标，只显示该实测点，不补造达到阈值的曲线。两个仓库均在MuJoCo3.11 CPU中完成完整动作评测，指标一致、参考数组逐元素相同，但保留各自原生模型、控制器和仿真步长。',
            '',f'横轴为真实4090训练walltime，线性显示0–{xmax}分钟，无时间缩放；RMSE/MPJPE为对数纵轴（刻度mm），PCK为百分比。没有平滑、补造0轮、删除FlashMimic的回落点。',
            '', 'crawl 的 FlashMimic 末轮精度回落，使阈值很宽松，不能据此展示时间优势。sprint 同样不能将宽松阈值等同于高精度收敛。flip 的 BeyondMimic 数据仅至1500轮，未达标不代表后续训练必然无法达标。',
            '', '原始来源、文件哈希、阈值和插值括区间见 `thresholds.json`；图中各点见 `plotted_points.csv`。']
    (out/'README.md').write_text('\n'.join(lines)+'\n')
    print(action,[(r['metric'],r['status'],r['time_min']) for r in records],flush=True)
    return records


def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'pdf.fonttype':42,'svg.fonttype':'none'})
    actions=sys.argv[1:] or ['walk','run','sprint','flip','box','crawl']
    records=[r for action in actions for r in make(action)]
    output=BASE/'MATCHED_ACCURACY_SIX_ACTIONS.json'
    output.write_text(json.dumps(records,indent=2))
    md=['# 六动作：FlashMimic / BeyondMimic MuJoCo 同阈值曲线','',
        '每项阈值取FlashMimic今天训练的17500轮指标。插值时间只估计两个已测检查点间的交点，不是实测达到时间。','',
        '| 动作（三指标总图） | FlashMimic末轮时间 | BeyondMimic RMSE目标 | BeyondMimic MPJPE目标 | BeyondMimic PCK目标 |',
        '|---|---:|---|---|---|']
    for a in actions:
        rr=[r for r in records if r['action']==a]
        cells=[]
        for r in rr:
            if r['status']=='interpolated_first_observed_crossing':cells.append(f"约{r['time_min']:.2f} min（插值）")
            elif r['status']=='already_met_at_first_checkpoint':cells.append(f"首点已达标（{r['time_min']:.2f} min）")
            else:cells.append(f"未达标（已测至{r['last_observed_time_min']:.2f} min）")
        path=f'./{a}_beyondmimic_flashmimic_mujoco_4090/matched_accuracy/{a}_three_metrics_matched_accuracy.png'
        md.append(f"| [{a}]({path}) | {rr[0]['flashmimic_final_walltime_min']:.2f} min | "+' | '.join(cells)+' |')
    md+=['','crawl末轮精度回落，初始BeyondMimic即优于目标，不能形成有效的精度收敛时间优势证据。sprint的末轮阈值也较宽松。flip的BeyondMimic仅保存到1500轮，因此只描述现有范围内未达到，不外推。抱箱子的RMSE、MPJPE在现有检查点均未达到，PCK可做交点估计。',
         '', '各动作目录含PNG/PDF/SVG、图中点CSV、阈值JSON和说明。全部原始轨迹哈希及指标已复核，两仓库同动作参考数组完全一致。保留原生动力学配置，不声称控制器及物理步长相同。',
         '', 'FlashMimic保留全部7点，不强行截到首次达到自身末轮指标的时间。插值只用于BeyondMimic；未做平滑、补造或时间缩放。']
    (BASE/'MATCHED_ACCURACY_SIX_ACTIONS.md').write_text('\n'.join(md)+'\n')


if __name__=='__main__':main()
