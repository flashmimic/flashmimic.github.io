from pathlib import Path
import csv,json,hashlib,math,importlib.util,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator,ScalarFormatter

BASE=Path('/home/user/flashmimic/plots')
SRC=Path('/home/user/下载/mjlab/mjlab_six_motions_18figures_native/six_motions_native_13body_v1')
FLIP_SRC=Path('/home/user/下载/mjlab_flip_final_3curves_20261015_022012/flip_final_curves_20261015_022012')
OUT=BASE/'four_repositories_six_actions_matched_accuracy'
ACTIONS=['dance','walk','run','flip','box']
MOTION={'dance':'dance','walk':'walk','run':'run','sprint':'sprint','box':'largebox'}
KEYS=['bodypos_rmse_mm','bodypos_mpjpe_mm','pck50_pct']
PANELS=[('bodypos_rmse_mm','Body position RMSE','Body position RMSE (mm; log scale)','mm'),('bodypos_mpjpe_mm','Body point MPJPE','Body point MPJPE (mm; log scale)','mm'),('pck50_pct','PCK@50 mm','PCK@50 mm (%)','%')]
NAMES={'dance':'Dance','walk':'Walk tracking','run':'Run','sprint':'Sprint','flip':'Flip','box':'Box carrying'}
STYLE={'BeyondMimic':('#2878b5','s'),'Holosoma':('#26936e','^'),'MJLab':('#8f5aaa','D'),'FlashMimic':('#d1495b','o')}
REPOS=['BeyondMimic','Holosoma','MJLab','FlashMimic']

msp=importlib.util.spec_from_file_location('common_metrics',BASE/'dance_pck_4090_v1/scripts/metrics.py');common=importlib.util.module_from_spec(msp);msp.loader.exec_module(common)
osp=importlib.util.spec_from_file_location('old_three',BASE/'plot_three_repositories_seven_actions.py');old=importlib.util.module_from_spec(osp);osp.loader.exec_module(old)

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def tkey(repo): return 'training_walltime_min' if repo=='Holosoma' else 'walltime_4090_min'
def time_basis(repo): return 'source logged hardware-unverified time' if repo=='Holosoma' else 'measured RTX4090 time'
def time_of(repo,row): return float(row[tkey(repo)])

EXTENDED_FLASHMIMIC = BASE/'flashmimic_extended_serial_20261014'

def load_extended_flashmimic(action):
    """Load the newly evaluated 4090 FlashMimic checkpoint curves.

    The extended runs contain more checkpoints than the original 17,500-step
    package.  Keep the measured cumulative TensorBoard walltime and the three
    MuJoCo metrics in the same row shape used by the existing plotting code.
    """
    path = EXTENDED_FLASHMIMIC/action/'results.csv'
    assert path.exists(), path
    rows=[]
    with path.open(newline='') as f:
        for r in csv.DictReader(f):
            assert r['training_gpu']=='NVIDIA GeForce RTX 4090'
            assert r['time_status']=='measured_4090'
            assert 'MuJoCo 3.11.0' in r['evaluation_simulator']
            row=dict(r)
            row['iteration']=str(int(r['iteration']))
            row['walltime_4090_min']=float(r['walltime_4090_min'])
            for key in KEYS: row[key]=float(r[key])
            rows.append(row)
    rows.sort(key=lambda r: float(r['walltime_4090_min']))
    assert rows and np.all(np.diff([r['walltime_4090_min'] for r in rows])>0)
    return rows

def point(repo,key,time,value,row=None,kind='measured'):
    return dict(repository=repo,metric=key,time=float(time),value=float(value),point_kind=kind,
                iteration='' if row is None else str(row.get('iteration','')),time_basis=time_basis(repo))

def full_points_from_groups(groups,action):
    out=[]
    for repo in ['BeyondMimic','Holosoma','FlashMimic']:
        for row in groups[action][repo]:
            for key in KEYS: out.append(point(repo,key,time_of(repo,row),row[key],row))
    return out

def crossing_points(repo,rows,key,target):
    x=np.array([time_of(repo,r) for r in rows],float); y=np.array([float(r[key]) for r in rows],float)
    ids=np.flatnonzero(y>=target if key=='pck50_pct' else y<=target)
    if not len(ids):
        return [point(repo,key,t,v,r) for t,v,r in zip(x,y,rows)],dict(repository=repo,metric=key,status='not_reached_by_available_checkpoints',time_min=None,last_observed_time_min=float(x[-1]),best_observed_value=float(y.max() if key=='pck50_pct' else y.min()),time_basis=time_basis(repo))
    i=int(ids[0])
    if i==0:
        return [point(repo,key,x[0],y[0],rows[0])],dict(repository=repo,metric=key,status='already_met_at_first_checkpoint',time_min=float(x[0]),time_basis=time_basis(repo),exact_crossing_time_unknown=True)
    f=(target-y[i-1])/(y[i]-y[i-1]); t=float(x[i-1]+f*(x[i]-x[i-1]))
    ps=[point(repo,key,xx,yy,rr) for xx,yy,rr in zip(x[:i],y[:i],rows[:i])]
    ps.append(point(repo,key,t,target,None,'linear_interpolation'))
    return ps,dict(repository=repo,metric=key,status='interpolated_first_observed_crossing',time_min=t,bracket_times=[float(x[i-1]),float(x[i])],bracket_values=[float(y[i-1]),float(y[i])],time_basis=time_basis(repo))

def load_mjlab(action):
    if action=='flip':
        # Updated native MJLab flip package supplies the complete metric CSV and audit metadata.
        csvrows=list(csv.DictReader((FLIP_SRC/'results.csv').open())); assert len(csvrows)==56
        rows=[]
        for r in sorted(csvrows,key=lambda z:int(z['iteration'])):
            assert r['training_gpu']=='NVIDIA GeForce RTX 4090' and r['evaluation_gpu']=='NVIDIA GeForce RTX 4090'
            assert int(r['frames'])==225 and r['time_status']=='measured_4090'
            vals={k:float(r[k]) for k in KEYS}; assert vals['bodypos_rmse_mm']>=vals['bodypos_mpjpe_mm']>=0 and 0<=vals['pck50_pct']<=100
            rows.append(dict(iteration=str(r['iteration']),walltime_4090_min=float(r['walltime_4090_min']),**vals))
        pts=[]
        for r in rows:
            for key in KEYS: pts.append(point('MJLab',key,r['walltime_4090_min'],r[key],r))
        audit=dict(repository='MJLab',pending=False,source=str(FLIP_SRC/'results.csv'),source_sha256=sha(FLIP_SRC/'results.csv'),checkpoint_count=len(rows),raw_rollouts_verified=False,metrics_recomputed_by_source_package=True,training_gpu='NVIDIA GeForce RTX 4090',full_walltime_min=float(rows[-1]['walltime_4090_min']),source_package=str(FLIP_SRC))
        return pts,rows,audit
    folder=SRC/MOTION[action]; csvrows=list(csv.DictReader((folder/'results.csv').open())); assert len(csvrows)==61
    rows=[]; refs=None
    for r in sorted(csvrows,key=lambda z:int(z['iteration'])):
        it=int(r['iteration']); raw=folder/f'model_{it}_rollout.npz'; assert raw.exists()
        with np.load(raw) as a:
            arrays=[a[k].astype(np.float64) for k in ['reference_pos_m','reference_quat_xyzw','actual_pos_m','actual_quat_xyzw']]
            assert all(np.isfinite(q).all() for q in arrays)
            _,e=common.evaluate(*arrays,a['body_names'].tolist())
            d=e['body_pos_error'][:,[i for i,n in enumerate(common.TRACK) if n!='torso_link']]
            vals=[1000*np.sqrt(np.mean(d*d)),1000*np.mean(d),100*np.mean(d<=.05)]
            if refs is None: refs=a['reference_pos_m'].copy()
            else: assert np.array_equal(refs,a['reference_pos_m'])
        for key,v in zip(KEYS,vals):
            assert np.isclose(float(r[key]),v,rtol=1e-7,atol=1e-4),(action,it,key,r[key],v)
            rows.append(dict(iteration=str(it),walltime_4090_min=float(r['walltime_4090_min']),**{key:float(v) for key,v in zip(KEYS,vals)}))
    pts=[]
    for r in rows:
        for key in KEYS: pts.append(point('MJLab',key,r['walltime_4090_min'],r[key],r))
    audit=dict(repository='MJLab',pending=False,source=str(folder/'results.csv'),source_sha256=sha(folder/'results.csv'),checkpoint_count=61,raw_rollouts_verified=True,metrics_recomputed=True,training_gpu='NVIDIA GeForce RTX 4090',full_walltime_min=float(rows[-1]['walltime_4090_min']))
    return pts,rows,audit

def build_action(groups,action):
    targets={}; points=[]; records=[]
    if action=='dance':
        targets={k:float(groups[action]['FlashMimic'][-1][k]) for k in KEYS}
        for key in KEYS:
            rows=groups[action]['FlashMimic']; points.extend([point('FlashMimic',key,time_of('FlashMimic',r),r[key],r) for r in rows]); records.append(dict(repository='FlashMimic',metric=key,status='full_flashmimic_reference',time_min=time_of('FlashMimic',rows[-1]),time_basis=time_basis('FlashMimic')))
            for repo in ['BeyondMimic','Holosoma']:
                ps,rec=crossing_points(repo,groups[action][repo],key,targets[key]); points.extend(ps); records.append(rec)
        mjpoints,mjrows,mjaudit=load_mjlab(action)
        for key in KEYS:
            rows=mjrows; ps=[]
            vals=[r[key] for r in rows]
            # MJLab rows use a small adapter with the same time key.
            if vals:
                x=np.array([r['walltime_4090_min'] for r in rows]); y=np.array(vals); ids=np.flatnonzero(y>=targets[key] if key=='pck50_pct' else y<=targets[key])
                if not len(ids): ps=[point('MJLab',key,r['walltime_4090_min'],r[key],r) for r in rows]; rec=dict(repository='MJLab',metric=key,status='not_reached_by_available_checkpoints',time_min=None,last_observed_time_min=float(x[-1]),time_basis='measured RTX4090')
                elif int(ids[0])==0: ps=[point('MJLab',key,rows[0]['walltime_4090_min'],rows[0][key],rows[0])]; rec=dict(repository='MJLab',metric=key,status='already_met_at_first_checkpoint',time_min=float(x[0]),time_basis='measured RTX4090')
                else:
                    i=int(ids[0]);f=(targets[key]-y[i-1])/(y[i]-y[i-1]);t=float(x[i-1]+f*(x[i]-x[i-1]));ps=[point('MJLab',key,r['walltime_4090_min'],r[key],r) for r in rows[:i]]+[point('MJLab',key,t,targets[key],None,'linear_interpolation')];rec=dict(repository='MJLab',metric=key,status='interpolated_first_observed_crossing',time_min=t,bracket_times=[float(x[i-1]),float(x[i])],time_basis='measured RTX4090')
            points.extend(ps);records.append(rec)
    else:
        # All non-dance actions remain untruncated; target thresholds are intentionally absent.
        points.extend(full_points_from_groups(groups,action))
        for repo in ['BeyondMimic','Holosoma','FlashMimic']:
            for key in KEYS:
                rows=groups[action][repo];records.append(dict(repository=repo,metric=key,status='full_curve_no_truncation',time_min=time_of(repo,rows[-1]),time_basis=time_basis(repo)))
        mjpoints,mjrows,mjaudit=load_mjlab(action);points.extend(mjpoints)
        for key in KEYS:
            if mjrows: records.append(dict(repository='MJLab',metric=key,status='full_curve_no_truncation',time_min=float(mjrows[-1]['walltime_4090_min']),time_basis='measured RTX4090'))
            else: records.append(dict(repository='MJLab',metric=key,status='pending_missing_native_rollouts',time_min=None,time_basis='pending'))
    return targets,points,records,mjaudit

def plot_action(action,targets,points,records):
    out=OUT/action;out.mkdir(parents=True,exist_ok=True)
    max_t=max([p['time'] for p in points] or [60]);step=10 if max_t<=60 else 20 if max_t<=170 else 50;xmax=math.ceil(max_t/step)*step
    fig,axes=plt.subplots(1,3,figsize=(19,6.6),sharex=True)
    for ax,(key,title,label,unit) in zip(axes,PANELS):
        if action=='dance': ax.axhline(targets[key],color='#89939f',lw=.9,ls=(0,(4,4)))
        all_y=[]
        for repo in REPOS:
            ps=sorted([p for p in points if p['repository']==repo and p['metric']==key],key=lambda p:p['time']); meas=[p for p in ps if p['point_kind']!='linear_interpolation']
            c,m=STYLE[repo]
            if not meas:
                if action=='flip' and repo=='MJLab': continue
                continue
            x=np.array([p['time'] for p in meas]);y=np.array([p['value'] for p in meas]);all_y.extend(y)
            labelname=repo+('†' if repo=='Holosoma' else '')
            ax.plot(x,y,color=c,marker=m,ms=4,lw=1.8,mec='white',mew=.35,label=labelname)
            ints=[p for p in ps if p['point_kind']=='linear_interpolation']
            if ints:
                q=ints[-1];ax.plot([x[-1],q['time']],[y[-1],q['value']],color=c,lw=1.8,ls='--');ax.plot(q['time'],q['value'],marker='D',ms=6,mfc='white',mec=c,mew=1.3);end_t=q['time'];end_y=q['value'];suffix='*'
            else: end_t=x[-1];end_y=y[-1];suffix=''
            ax.annotate(f'{end_t:.2f} min{suffix}',(end_t,end_y),xytext=(0,(-22 if repo in ['BeyondMimic','MJLab'] else 14)),textcoords='offset points',ha='center',fontsize=8.2,color=c)
        
        ax.set_xlim(0,xmax);ax.xaxis.set_major_locator(MaxNLocator(nbins=7,steps=[1,2,2.5,5,10]));ax.set_xlabel('Training walltime (min)');ax.set_ylabel(label);ax.set_title(f'{NAMES[action]} | {title}'+(f'\nFlashMimic target: {targets[key]:.2f} {unit}' if action=='dance' else '\nFull available curves'),fontsize=12,pad=12)
        if key=='pck50_pct': ax.set_ylim(0,100)
        else:
            ax.set_yscale('log');lo=min(all_y+[targets.get(key,min(all_y or [1]))])*.72;hi=max(all_y+[targets.get(key,max(all_y or [1]))])*1.2;ax.set_ylim(lo,hi);ax.set_yticks([v for v in [10,20,30,40,60,100,200,400,600,1000,2000] if lo<=v<=hi]);ax.yaxis.set_major_formatter(ScalarFormatter());ax.minorticks_off()
        handles=[plt.Line2D([],[],color=STYLE[r][0],marker=STYLE[r][1],lw=1.8,label=r+('†' if r=='Holosoma' else '')) for r in REPOS]
        ax.legend(handles=handles,frameon=False,loc='upper right' if key!='pck50_pct' else 'lower right',fontsize=8.8)
        ax.grid(color='#e1e7ef',lw=.7);ax.set_axisbelow(True);ax.spines[['top','right']].set_visible(False)
    fig.suptitle(f'{NAMES[action]} | Four repositories | MuJoCo accuracy',fontsize=16,y=.98)
    if action=='dance': note='Dance uses FlashMimic model_17500 target; hollow diamonds/dashed segments are interpolated crossings.'
    elif action=='flip': note='Full available curves; MJLab flip uses the updated 56-checkpoint RTX4090 evaluation package.'
    else: note='Full available curves; no accuracy threshold or time truncation applied.'
    fig.text(.5,.073,note,ha='center',fontsize=9.2,color='#526079')
    fig.text(.5,.038,'† Holosoma time is source logged walltime, GPU unverified. BeyondMimic/FlashMimic and available MJLab time are measured RTX4090 training walltime.',ha='center',fontsize=9.2,color='#526079')
    fig.tight_layout(rect=(0,.14,1,.93),w_pad=2)
    for ext in ['png','pdf','svg']:fig.savefig(out/f'{action}_four_repositories_{"matched_accuracy" if action=="dance" else "full_accuracy"}.{ext}',dpi=220)
    plt.close(fig)
    fields=['repository','metric','time_min','value','point_kind','iteration','time_basis']
    with (out/'plotted_points.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows([{**{k:p.get(k,'') for k in fields if k!='time_min'},'time_min':p.get('time',p.get('time_min',''))} for p in points])
    return xmax

def main():
    if OUT.exists(): shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    groups=old.prepare(); allp=[]; audits={}
    # Keep dance on the previously validated 17,500-step curve.  For the
    # other five displayed actions use the newly supplied serial 4090 runs,
    # whose checkpoints extend well beyond 17,500 steps.
    for action in ['walk','run','flip','box']:
        groups[action]['FlashMimic']=load_extended_flashmimic(action)
    for action in ACTIONS:
        targets,points,records,audit=build_action(groups,action);xmax=plot_action(action,targets,points,records);allp.append((action,targets,points,xmax));audits[action]=audit
        flash_source = None
        if action in ['walk','run','flip','box']:
            flash_source = dict(
                directory=str(EXTENDED_FLASHMIMIC/action),
                results_csv=str(EXTENDED_FLASHMIMIC/action/'results.csv'),
                results_sha256=sha(EXTENDED_FLASHMIMIC/action/'results.csv'),
                checkpoint_count=len(groups[action]['FlashMimic']),
                first_iteration=int(groups[action]['FlashMimic'][0]['iteration']),
                last_iteration=int(groups[action]['FlashMimic'][-1]['iteration']),
                final_walltime_4090_min=float(groups[action]['FlashMimic'][-1]['walltime_4090_min']),
                training_gpu='NVIDIA GeForce RTX 4090',
                evaluation_backend='MuJoCo 3.11.0 CPU',
            )
        (OUT/action/'provenance.json').write_text(json.dumps(dict(action=action,targets=targets,records=records,mjlab=audit,flashmimic_extended=flash_source,curve_policy='dance matched target; other displayed actions full available curves'),indent=2))
        print(action,[(r['repository'],r['metric'],r['status'],r.get('time_min')) for r in records if r['metric']==KEYS[0]],flush=True)
    # Sprint has been removed from the displayed action set.  Use the actual
    # number of actions so the old sprint row cannot leave three blank panels.
    fig,axes=plt.subplots(len(allp),3,figsize=(19,4.0*len(allp)+1.0),squeeze=False)
    for row,(action,targets,points,xmax) in zip(axes,allp):
        for ax,(key,title,label,unit) in zip(row,PANELS):
            if action=='dance': ax.axhline(targets[key],color='#89939f',lw=.6,ls=(0,(3,3)))
            vals=[]
            for repo in REPOS:
                ps=sorted([p for p in points if p['repository']==repo and p['metric']==key],key=lambda p:p['time']);meas=[p for p in ps if p['point_kind']!='linear_interpolation']
                if not meas:continue
                x=np.array([p['time'] for p in meas]);y=np.array([p['value'] for p in meas]);vals.extend(y);c,m=STYLE[repo];ax.plot(x,y,color=c,marker=m,ms=2.5,lw=1.05,mec='white',mew=.2)
                ints=[p for p in ps if p['point_kind']=='linear_interpolation']
                if ints:
                    q=ints[-1];ax.plot([x[-1],q['time']],[y[-1],q['value']],color=c,lw=1.05,ls='--');ax.plot(q['time'],q['value'],marker='D',ms=3,mfc='white',mec=c,mew=.7)
            ax.set_xlim(0,xmax);ax.tick_params(labelsize=7);ax.set_title(f'{NAMES[action]} | {title}',fontsize=8.5,pad=5);ax.set_xlabel('walltime (min)',fontsize=7);ax.set_ylabel(label,fontsize=7);ax.grid(color='#e1e7ef',lw=.4);ax.set_axisbelow(True);ax.spines[['top','right']].set_visible(False)
            if key=='pck50_pct':ax.set_ylim(0,100)
            elif vals:
                lo=min(vals+[targets.get(key,min(vals))])*.72;hi=max(vals+[targets.get(key,max(vals))])*1.2;ax.set_yscale('log');ax.set_ylim(lo,hi);ax.yaxis.set_major_formatter(ScalarFormatter());ax.minorticks_off()
    handles=[plt.Line2D([],[],color=STYLE[r][0],marker=STYLE[r][1],lw=1.6,label=r+('†' if r=='Holosoma' else '')) for r in REPOS];fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.987),ncol=4,frameon=False,fontsize=11);fig.suptitle('Five actions | Four repositories | Dance matched, others full curves',fontsize=17,y=.998);fig.text(.5,.016,'† Holosoma GPU unverified/source logged time. MJLab flip uses the updated 56-checkpoint RTX4090 evaluation package.',ha='center',fontsize=9.5,color='#526079');fig.tight_layout(rect=(0,.027,1,.975),h_pad=1.5,w_pad=2)
    for ext in ['png','pdf','svg']:fig.savefig(OUT/f'six_actions_four_repositories_overview.{ext}',dpi=180 if ext=='png' else 220)
    plt.close(fig)
    endpoints=[]
    for action,targets,points,xmax in allp:
        for repo in REPOS:
            for key in KEYS:
                ps=[p for p in points if p['repository']==repo and p['metric']==key]
                if ps:
                    q=max(ps,key=lambda p:p['time']); endpoints.append(dict(action=action,repository=repo,metric=key,display_endpoint_walltime_min=q['time'],point_kind=q['point_kind'],time_basis=q['time_basis']))
                else:endpoints.append(dict(action=action,repository=repo,metric=key,display_endpoint_walltime_min='',point_kind='pending',time_basis='pending'))
    with (OUT/'endpoint_times.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(endpoints[0]));w.writeheader();w.writerows(endpoints)
    extended_summary={a:dict(checkpoint_count=len(groups[a]['FlashMimic']),first_iteration=int(groups[a]['FlashMimic'][0]['iteration']),last_iteration=int(groups[a]['FlashMimic'][-1]['iteration']),final_walltime_4090_min=float(groups[a]['FlashMimic'][-1]['walltime_4090_min'])) for a in ['walk','run','flip','box']}
    (OUT/'summary.json').write_text(json.dumps(dict(actions=ACTIONS,dance_policy='FlashMimic model_17500 matched target',other_actions_policy='full curves no truncation',flashmimic_extended_source=str(EXTENDED_FLASHMIMIC),flashmimic_extended=extended_summary,flip_mjlab='updated_56_checkpoint_package',mjlab_flip_source=str(FLIP_SRC),mjlab_flip_checkpoint_count=56,crawl_excluded=True,mjlab_source=str(SRC)),indent=2))
    shutil.copy2(BASE/'metric_definitions_four_repositories.md', OUT/'metric_definitions.md')
    (OUT/'README.md').write_text('''# 五动作四仓库汇总\n\n动作集合为 dance、walk、run、flip、box carrying，已排除 sprint 和 crawl。dance 按 FlashMimic model_17500 三项指标进行同精度截取；walk、run、flip 和 box carrying 使用当前可用数据的全量曲线，不做截取，便于后续根据新的 FlashMimic 高精度目标统一截取。\n\n本次更新将 walk、run、flip、box carrying 的 FlashMimic 曲线替换为 `/home/user/flashmimic/flashsac/FlashMimic/logs/converged_serial_20261014_233238` 下的新 4090 训练结果，并在 MuJoCo 3.11.0 CPU 中对每个 checkpoint 重新 rollout 计算三项指标。各动作的 checkpoint 数、最后轮次和最终累计 4090 walltime 记录在各动作 `provenance.json` 以及根目录 `summary.json` 中。dance 保持原来的 FlashMimic 曲线。\n\nflip 使用新提供的 56 个完整 MJLab RTX4090 评测点（model_0 至 model_27500）。\n\nHolosoma 的 GPU 未核实，使用 source logged walltime，以 † 标注；其余已存在曲线按各自记录的 RTX4090 walltime。每条曲线终点时间见 `endpoint_times.csv`。\n\n三个纵轴指标的统一定义、公式和计算代码见 `metric_definitions.md`。\n''')
    print(OUT)
if __name__=='__main__':main()
