"""Overlay exported Holosoma results with local MuJoCo accuracy curves.

Hardware-unverified Holosoma time is intentionally never labelled RTX4090.
"""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, ScalarFormatter
import numpy as np

BASE=Path('/home/user/flashmimic/plots')
HOLO=Path('/home/user/下载/holosoma_21_plots')
OUT=BASE/'three_repositories_7actions_matched_accuracy'
OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('previous',BASE/'plot_matched_accuracy_actions.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
ACTIONS=['dance','walk','run','sprint','flip','box','crawl']
NAMES=dict(old.NAMES,dance='Dance tracking')
MAP={'dance':'Dance','walk':'Walk','run':'Run','sprint':'Sprint','flip':'Flip','box':'Largebox','crawl':'Crawl'}
STYLE={'FlashMimic':('#d1495b','o'),'BeyondMimic':('#2878b5','s'),'Holosoma':('#26936e','^')}
PANELS=old.PANELS
REPOS=['BeyondMimic','Holosoma','FlashMimic']


def read_csv(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))


def load_local(action,repo):
    if action!='dance':return old.load(action,repo)
    p=BASE/f'{repo}_{action}_mujoco_4090/results.csv'
    rows=sorted(read_csv(p),key=lambda r:float(r['walltime_4090_min']))
    for r in rows:
        assert r['time_status']=='measured_4090' and '4090' in r['training_gpu']
        assert 'MuJoCo 3.11.0' in r['evaluation_simulator']
        assert old.sha(r['trajectory'])==r['trajectory_sha256']
        with np.load(r['trajectory']) as a:
            arrays=[a[k].astype(np.float64) for k in ['reference_pos_m','reference_quat_xyzw','actual_pos_m','actual_quat_xyzw']]
            _,e=old.metric.evaluate(*arrays,a['body_names'].tolist())
        d=e['body_pos_error'][:,[i for i,n in enumerate(old.metric.TRACK) if n!='torso_link']]
        values=[1000*np.sqrt(np.mean(d*d)),1000*np.mean(d),100*np.mean(d<=.05)]
        assert all(np.isclose(float(r[k]),v,rtol=1e-10,atol=1e-10) for k,v in zip(old.KEYS,values))
    return rows,None,dict(repository=repo,path=str(p),sha256=old.sha(p),checkpoint_count=len(rows))


def prepare():
    holo_csv=read_csv(HOLO/'results.csv')
    holo_json=json.loads((HOLO/'results.json').read_text())
    assert len(holo_csv)==len(holo_json)==273
    lookup={(r['motion'],int(r['iteration'])):r for r in holo_json}
    assert len(lookup)==273
    source_dir=OUT/'source_snapshots';source_dir.mkdir(exist_ok=True)
    for name in ['README.md','results.csv','results.json','validation.json','summary.json','last_checkpoint_summary.csv']:
        shutil.copy2(HOLO/name,source_dir/f'holosoma_{name}')
    source_hashes={str(HOLO/n):old.sha(HOLO/n) for n in ['README.md','results.csv','results.json','validation.json','summary.json']}
    groups={}
    all_sources=[]
    for action in ACTIONS:
        flash,fr,fs=load_local(action,'flashmimic');beyond,br,bs=load_local(action,'beyondmimic')
        if action!='dance':assert all(np.array_equal(fr[k],br[k]) for k in fr)
        holo=sorted([r for r in holo_csv if r['motion']==MAP[action]],key=lambda r:float(r['training_walltime_min']))
        assert holo and int(flash[-1]['iteration'])==17500
        for r in holo:
            j=lookup[(r['motion'],int(r['iteration']))]
            assert r['training_gpu']=='unverified' and not r['walltime_4090_min']
            for key in old.KEYS+['training_walltime_min']:
                assert float(r[key])==float(j[key]) and np.isfinite(float(r[key]))
            assert int(r['frames'])==int(r['frames_expected'])==int(flash[0]['frames'])
            assert float(r['bodypos_rmse_mm'])+1e-8>=float(r['bodypos_mpjpe_mm'])>=0
            assert 0<=float(r['pck50_pct'])<=100
            assert np.isclose(float(r['training_walltime_min']),
                              (float(r['checkpoint_logged_unix_s'])-float(r['time_origin_unix_s']))/60,atol=1e-9)
        groups[action]={'FlashMimic':flash,'BeyondMimic':beyond,'Holosoma':holo}
        for repo,rows in groups[action].items():
            key='training_walltime_min' if repo=='Holosoma' else 'walltime_4090_min'
            assert np.all(np.diff([float(r[key]) for r in rows])>0)
        all_sources.extend([dict(action=action,**s) for s in [fs,bs]])
    (OUT/'source_validation.json').write_text(json.dumps(dict(
        holosoma_count=273,holosoma_csv_json_values_match=True,holosoma_frame_counts_and_metric_bounds_checked=True,
        holosoma_logged_time_formula_checked=True,holosoma_training_gpu_verified=False,
        holosoma_raw_rollouts_in_package=False,holosoma_metrics_independently_recomputed=False,
        local_metrics_recomputed_from_hashed_trajectories=True,
        local_six_actions_reference_arrays_identical=True,
        dance_local_reference_audit=json.loads((BASE/'flashmimic_dance_mujoco_4090/validation.json').read_text())['beyondmimic_reference_comparison'],
        cross_repository_holosoma_reference_arrays_verified=False,
        holosoma_source_hashes=source_hashes,local_sources=all_sources),indent=2))
    return groups


def time_array(repo,rows):
    return np.array([float(r['training_walltime_min' if repo=='Holosoma' else 'walltime_4090_min']) for r in rows])


def clipped(repo,rows,key,target):
    normalized=[dict(r,walltime_4090_min=float(t)) for r,t in zip(rows,time_array(repo,rows))]
    # Existing numerical crossing helper only reads this key. For Holosoma it
    # receives the recorded source time; no generated CSV ever calls it 4090.
    rec=old.crossing(normalized,key,target)
    rec['repository']=repo
    rec['time_basis']='source logged hardware-unverified time' if repo=='Holosoma' else 'measured RTX4090 time'
    x=time_array(repo,rows);y=np.array([float(r[key]) for r in rows])
    status=rec['status']
    n=rec['hit_index'] if status=='interpolated_first_observed_crossing' else 1 if status=='already_met_at_first_checkpoint' else len(rows)
    points=[dict(repository=repo,metric=key,time_min=float(t),value=float(v),point_kind='measured',iteration=r['iteration'],time_basis=rec['time_basis'])
            for t,v,r in zip(x[:n],y[:n],rows[:n])]
    if status=='interpolated_first_observed_crossing':
        points.append(dict(repository=repo,metric=key,time_min=rec['time_min'],value=target,
                           point_kind='linear_interpolation',iteration='',time_basis=rec['time_basis']))
    return rec,points


def make_payload(action,group):
    targets={k:float(group['FlashMimic'][-1][k]) for k in old.KEYS}
    records=[];points=[]
    for key in old.KEYS:
        for repo in REPOS:
            if repo=='FlashMimic':
                rows=group[repo];times=time_array(repo,rows)
                rec=dict(repository=repo,status='final_checkpoint_reference',time_min=float(times[-1]),time_basis='measured RTX4090 time')
                pp=[dict(repository=repo,metric=key,time_min=float(t),value=float(r[key]),point_kind='measured',iteration=r['iteration'],time_basis=rec['time_basis']) for t,r in zip(times,rows)]
            else:rec,pp=clipped(repo,group[repo],key,targets[key])
            records.append(dict(action=action,metric=key,target=targets[key],**rec))
            points.extend(pp)
    maxt=max(p['time_min'] for p in points)
    step=2 if maxt<=10 else 5 if maxt<=25 else 10 if maxt<=60 else 20 if maxt<=170 else 30
    xmax=math.ceil(maxt/step)*step
    if xmax-maxt<step*.12:xmax+=step
    return dict(action=action,targets=targets,records=records,points=points,xmax=xmax)


def panel(ax,payload,key,title,label,compact=False):
    target=payload['targets'][key];ax.axhline(target,color='#89939f',lw=.9,ls=(0,(4,4)),zorder=1)
    values=[];labels=[]
    for repo in REPOS:
        rec=next(r for r in payload['records'] if r['repository']==repo and r['metric']==key)
        pp=sorted([p for p in payload['points'] if p['repository']==repo and p['metric']==key],key=lambda p:p['time_min'])
        measured=[p for p in pp if p['point_kind']=='measured'];x=[p['time_min'] for p in measured];y=[p['value'] for p in measured]
        color,marker=STYLE[repo];values.extend(y)
        display=repo+'†' if repo=='Holosoma' else repo
        ax.plot(x,y,color=color,marker=marker,ms=3 if compact else 4.4,lw=1.5 if compact else 1.9,
                mec='white',mew=.35,label=display,ls='None' if len(x)==1 else '-')
        status=rec['status']
        if status=='interpolated_first_observed_crossing':
            t=rec['time_min'];ax.plot([x[-1],t],[y[-1],target],color=color,lw=1.5 if compact else 1.9,ls='--')
            ax.plot(t,target,marker='D',ms=4.5 if compact else 6,mfc='white',mec=color,mew=1.2)
            values.append(target);status_label=f'{display}: {t:.2f} min*'
        elif status=='already_met_at_first_checkpoint':status_label=f'{display}: already met at {rec["time_min"]:.2f} min'
        elif status=='not_reached_by_available_checkpoints':status_label=f'{display}: not reached by {rec["last_observed_time_min"]:.2f} min'
        else:status_label=f'{display}: final at {rec["time_min"]:.2f} min'
        labels.append((status_label,color))
    ax.set_xlim(0,payload['xmax']);ax.xaxis.set_major_locator(MaxNLocator(nbins=5 if compact else 6,steps=[1,2,2.5,5,10]))
    if key=='pck50_pct':ax.set_ylim(0,100)
    else:
        ax.set_yscale('log');lo=min(values+[target])*.72;hi=max(values+[target])*1.2
        ax.set_ylim(lo,hi);ax.set_yticks([v for v in [10,20,30,40,60,100,200,400,600,1000,2000] if lo<=v<=hi])
        ax.yaxis.set_major_formatter(ScalarFormatter());ax.minorticks_off()
    ax.set_ylabel(label,fontsize=8 if compact else 10)
    ax.set_xlabel('Logged training walltime (min)',fontsize=8 if compact else 10)
    threshold=f'{target:.2f}%' if key=='pck50_pct' else f'{target:.2f} mm'
    ax.set_title((NAMES[payload['action']]+' | ' if compact else '')+f'{title}\nFlashMimic target: {threshold}',fontsize=9.5 if compact else 12,pad=9)
    ax.grid(color='#e1e7ef',lw=.6);ax.set_axisbelow(True);ax.spines[['top','right']].set_visible(False)
    ax.tick_params(labelsize=7.5 if compact else 10)
    if not compact:
        ax.legend(frameon=False,fontsize=9,loc='upper right' if key!='pck50_pct' else 'lower right')
        # Use a fixed text block outside each axis to avoid overlapping endpoints.
        for i,(txt,c) in enumerate(labels):ax.text(0,-.21-i*.058,txt,transform=ax.transAxes,color=c,fontsize=9)


def save_one(payload):
    action=payload['action'];out=OUT/action;out.mkdir(exist_ok=True)
    fig,axes=plt.subplots(1,3,figsize=(18,6.6),sharex=True)
    for ax,(key,title,label,_) in zip(axes,PANELS):panel(ax,payload,key,title,label)
    fig.suptitle(f'{NAMES[action]} | FlashMimic, BeyondMimic and Holosoma | MuJoCo accuracy',fontsize=16,y=.98)
    fig.text(.5,.069,'Targets: FlashMimic model_17500. * Interpolated crossing; targets not reached: full available curve; initially met: first measured point.',ha='center',fontsize=9,color='#526079')
    fig.text(.5,.034,'† Holosoma: training GPU unverified; time starts at logged iteration 100. FlashMimic/BeyondMimic: measured RTX 4090 time.',ha='center',fontsize=9,color='#526079')
    fig.tight_layout(rect=(0,.17,1,.93),w_pad=2)
    for ext in ['png','pdf','svg']:fig.savefig(out/f'{action}_three_repositories_matched_accuracy.{ext}',dpi=220)
    plt.close(fig)
    with (out/'plotted_points.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(payload['points'][0]));w.writeheader();w.writerows(payload['points'])
    (out/'thresholds.json').write_text(json.dumps(payload,indent=2))


def summary(payloads):
    lines=['# 七动作：FlashMimic、BeyondMimic、Holosoma 三仓库精度曲线','',
           '每动作一张三联图，另含七动作×三指标总览。以FlashMimic今天17500轮指标为各子图目标；达标者截至首个观测跨阈值区间内的线性插值交点，未达标者展示全部检查点。初始检查点已达标者仅显示首点，不补造曲线。FlashMimic保留全部7个实测点，包括回落。',
           '', '**时间口径：Holosoma训练显卡未核实，且从第100轮首条日志开始计时，前100轮不包含；本版未换算成4090，横轴只能标“Logged training walltime”。FlashMimic/BeyondMimic为已有4090实测时间。本版不能称为三仓库同4090速度对比。**',
           '', 'MuJoCo评测和13个非torso身体点、torso平移+相对yaw对齐的指标口径来自各自结果说明。Holosoma仅提供数值表与图，无原始轨迹、参考NPZ或评测脚本；可核对CSV/JSON及帧数、统计边界和时间公式，无法独立重算其指标或验证跨仓库参考数组完全一致。其说明披露约10mm的模型几何差异，保留在误差中。FlashMimic与BeyondMimic的原始轨迹指标已复算；六动作参考相同，dance对齐后参考点最大差异约0.684mm。各仓库保留原生动力学配置。',
           '', '| 动作 | 指标 | FlashMimic末轮 | BeyondMimic | Holosoma† |','|---|---|---:|---|---|']
    def desc(r):
        if r['status']=='interpolated_first_observed_crossing':return f"约{r['time_min']:.2f} min（插值）"
        if r['status']=='already_met_at_first_checkpoint':return f"首点已达标，{r['time_min']:.2f} min"
        return f"未达标，展示至{r['last_observed_time_min']:.2f} min"
    flat=[]
    for p in payloads:
        a=p['action'];link=f'[{a}](./{a}/{a}_three_repositories_matched_accuracy.png)'
        for key,title,_,unit in PANELS:
            rr={r['repository']:r for r in p['records'] if r['metric']==key};flat.extend(rr.values())
            lines.append(f"| {link} | {title}（{p['targets'][key]:.2f} {unit}） | {rr['FlashMimic']['time_min']:.2f} min | {desc(rr['BeyondMimic'])} | {desc(rr['Holosoma'])} |")
    lines+=['','[七动作×三指标总览](./seven_actions_three_repositories_overview.png)。各动作目录含PNG/PDF/SVG、图中点CSV和阈值JSON；source_snapshots保存Holosoma输入数据副本，source_validation.json记录核对范围和哈希。',
            '', 'crawl的FlashMimic末轮精度明显回落，目标过于宽松，不能据此声称时间优势；sprint的末轮精度也较低。未达标仅描述现有检查点，不代表后续永远无法达到。插值时刻是估算，非额外模型实测。本版无平滑、无外推、无归一化终点或时间缩放。']
    (OUT/'README.md').write_text('\n'.join(lines)+'\n')
    (OUT/'all_thresholds.json').write_text(json.dumps(flat,indent=2))


def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'svg.fonttype':'none'})
    groups=prepare();payloads=[]
    for action in ACTIONS:
        p=make_payload(action,groups[action]);save_one(p);payloads.append(p)
        print(action,[(r['repository'],r['metric'],r['status'],r.get('time_min')) for r in p['records'] if r['repository']=='Holosoma'],flush=True)
    fig,axes=plt.subplots(7,3,figsize=(17,25))
    for row,p in zip(axes,payloads):
        for ax,(key,title,label,_) in zip(row,PANELS):panel(ax,p,key,title,label,compact=True)
    handles=[plt.Line2D([],[],color=STYLE[r][0],marker=STYLE[r][1],lw=1.7,label=r+('†' if r=='Holosoma' else '')) for r in REPOS]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.982),ncol=3,frameon=False,fontsize=11)
    fig.suptitle('Seven actions | Three repositories | FlashMimic final-accuracy targets',fontsize=17,y=.995)
    fig.text(.5,.018,'† Holosoma GPU unverified; source time begins at iteration 100. Other two: measured RTX 4090. Hollow endpoint: interpolated crossing.',ha='center',fontsize=10,color='#526079')
    fig.text(.5,.006,'Unreached targets retain full curves; targets already met initially show the first point. Native MuJoCo scenes differ; imported Holosoma raw rollouts unavailable.',ha='center',fontsize=9.5,color='#526079')
    fig.tight_layout(rect=(0,.027,1,.97),h_pad=1.8,w_pad=2)
    for ext in ['png','pdf','svg']:fig.savefig(OUT/f'seven_actions_three_repositories_overview.{ext}',dpi=180 if ext=='png' else 220)
    plt.close(fig);summary(payloads)
    print(OUT,flush=True)


if __name__=='__main__':main()
