# 四仓库 MuJoCo 三指标定义

本目录的曲线统一使用 MuJoCo rollout 产生的 13 个非 torso body link 的位置误差。对每一帧，先把参考动作与实际 rollout 做 torso 平移对齐，并用 torso yaw 做相对朝向对齐；随后比较同名 body link 原点的位置。记 `d[t,b]` 为第 `t` 帧、第 `b` 个 body link 的三维欧氏距离（单位 m），`T` 为完整动作帧数，`B=13`。

所有指标都在同一批 `T×13` 个 body-link 样本上计算，避免把不同仓库的 episode 长度或 reward 聚合方式混入精度指标。三项指标均来自 MuJoCo 当前积分后的机器人状态，而不是 TensorBoard reward 反推值。

## Body Position RMSE

```text
RMSE_mm = 1000 * sqrt( (1 / (13*T)) * sum_t=1..T sum_b=1..13 d[t,b]^2 )
```

先对每个位置误差平方，再对全部帧和 body link 求平均，最后开平方并换算为毫米。它对较大的位置偏差更敏感；数值越小表示位置精度越高。

## MPJPE（13 个 body-link 原点）

```text
MPJPE_mm = (1000 / (13*T)) * sum_t=1..T sum_b=1..13 d[t,b]
```

直接平均所有帧、所有 body link 的三维欧氏距离，单位为毫米，数值越小越好。这里的“关节点”是机器人 body link 原点，不是人体数据集的解剖学关节中心，因此论文中应写明是 **13-point robot body-link MPJPE**。

## PCK@50mm

```text
PCK@50mm_percent = (100 / (13*T)) * sum_t=1..T sum_b=1..13 1[d[t,b] <= 0.05]
```

`1[·]` 是指示函数：当该帧该 body link 的位置误差不超过 50 mm 时取 1，否则取 0。这里统计的是 **所有帧、所有 body link 样本中** 的合格比例，并不是“某一帧的 13 个 body 全部同时落在 50 mm 内”的帧比例。数值越高越好。

50 mm 是一个固定、易解释的宽松容差，适合作为补充的成功率指标；它不是唯一或充分的精度标准，主指标仍建议报告 RMSE 和 MPJPE，并在论文中明确 50 mm 阈值。若需要检验阈值敏感性，可另外报告 PCK@25mm 或 PCK@75mm，但不能把不同阈值混在同一主结果中。

## 曲线和时间口径

每个曲线点对应一个真实 checkpoint 的完整动作 rollout；线段仅连接相邻实测 checkpoint，不做平滑、单调化或 reward 反推。横轴是训练期间 TensorBoard 事件段累计得到的 RTX 4090 walltime（分钟）。Holosoma 的输入曲线保留其源日志时间，并在图例中用 `†` 标出 GPU 未独立核实；FlashMimic、BeyondMimic 和 MJLab 可用曲线使用各自记录的 RTX 4090 时间。

图中三个指标不要求终点数值相同：它们保留各仓库在统一 MuJoCo、统一 body-link 集合和统一对齐规则下的实际误差/成功率。dance 使用既有的同精度截取版本；其余动作当前展示所有可用 checkpoint，后续可按统一精度目标再截取。
