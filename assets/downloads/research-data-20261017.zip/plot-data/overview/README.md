# 五动作四仓库汇总

动作集合为 dance、walk、run、flip、box carrying，已排除 sprint 和 crawl。dance 按 FlashMimic model_17500 三项指标进行同精度截取；walk、run、flip 和 box carrying 使用当前可用数据的全量曲线，不做截取，便于后续根据新的 FlashMimic 高精度目标统一截取。

本次更新将 walk、run、flip、box carrying 的 FlashMimic 曲线替换为 `/home/user/flashmimic/flashsac/FlashMimic/logs/converged_serial_20261014_233238` 下的新 4090 训练结果，并在 MuJoCo 3.11.0 CPU 中对每个 checkpoint 重新 rollout 计算三项指标。各动作的 checkpoint 数、最后轮次和最终累计 4090 walltime 记录在各动作 `provenance.json` 以及根目录 `summary.json` 中。dance 保持原来的 FlashMimic 曲线。

flip 使用新提供的 56 个完整 MJLab RTX4090 评测点（model_0 至 model_27500）。

Holosoma 的 GPU 未核实，使用 source logged walltime，以 † 标注；其余已存在曲线按各自记录的 RTX4090 walltime。每条曲线终点时间见 `endpoint_times.csv`。

三个纵轴指标的统一定义、公式和计算代码见 `metric_definitions.md`。

## 最新五动作概览

`six_actions_four_repositories_overview.*` 已重新排版为五行三列，删除 sprint 原来占用的最后一行空白子图；`crawl` 仍未纳入。为避免目录名称引起歧义，同时提供同内容的 `five_actions_four_repositories_overview.*` 别名。

用于绘图的数据、MuJoCo 推理输出和五个动作对应的 TensorBoard event 文件已打包为 `five_actions_plot_data_20261015.zip`。数据包不含策略权重；清单见 `five_actions_plot_data_manifest.json`。
