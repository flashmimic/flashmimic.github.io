# 五动作最终汇总：原始资料归档

主表任务为 dance、walk、run、flip、carry；sprint 子表仅供参考，crawl 不参与主表。

## 目录

- `checkpoints/`：六张子表的 30 个所选评测权重，含原四仓库和 FlashSAC 延长训练参考行。仅归档所选权重，不含全部训练候选、replay buffer 或优化器之外的外部训练状态。
- `tensorboard/`：原始 event 文件，含所选运行、续训段，以及 baseline_date 中 4090/5090 校准与历史对照曲线。按内容去重；相同文件的所有原路径均记录在 SOURCE_MAP.json。历史曲线不代表当前精度权重，配对关系以 SELECTED_CHECKPOINTS.json 为准。
- `training_configs/`：所选运行保存的 YAML/JSON 配置。
- `training_logs/`：本地 BeyondMimic 原始终端训练日志和串行调度记录。
- `evidence/motion_tracking_6run/`：本次整理时的原始评测产物快照，含 motion NPZ、推理轨迹、逐帧误差、DR 证据、扫描记录、指标/汇总脚本、计时审计及历史报告。历史文件保留供追溯，当前入口始终为根目录 final_report.md。
- `references_and_trajectories/`：所选评测引用的其他 motion/轨迹文件。
- `SELECTED_CHECKPOINTS.json`：方法—动作—权重—实测指标—时间来源索引。
- `SOURCE_MAP.json`：原始绝对路径到压缩包内部路径的映射。
- `SHA256SUMS.txt`：每个归档文件的 SHA256，可在本目录运行 `sha256sum -c SHA256SUMS.txt` 验证。

## 查看 TensorBoard

在已安装 TensorBoard 的环境中执行：

```bash
tensorboard --logdir tensorboard --port 6006
```

原始 JSON/脚本保留当时的绝对路径作为来源证据；换机器使用时通过 SOURCE_MAP.json 定位，不保证脚本无需改路径即可执行。本包不包含完整四仓库代码、机器人资产或可运行仿真环境，不能单靠解压独立重新推理；可直接审阅指标、轨迹和 TensorBoard。

## 数据范围与来源

原始文件仅复制，未修改训练日志、权重或重新训练。所有所选权重均与评测记录的 SHA256 核对一致。归档只含与报告有关的资料，不包括 SSH 密钥、环境凭据或整个工作区。

最终报告第五行 dance 的误差为用户指定调整值，不是所列 model_45000.pt 的实测误差；相应平均误差也包含该调整。原始推理结果和调整过程均保留，可由 SELECTED_CHECKPOINTS.json 和 evidence 中的 selected_results.json、dance_manual_adjustment_report_data.json 分别核查。其成功率和时间来自参考运行，不能解释为达到调整后精度的实测时间。

各方法 Succ 均以五任务为分母；误差与时间按成功动作等权平均：BeyondMimic 为 dance/walk/run/carry（4），MJLab 与两行 FlashSAC 为全部五动作（5），Holosoma 为 dance/walk/run（3）。使用未取整数据、不按帧数加权。D/E/P 及续训时间重建来源以 final_report.md 为准。
